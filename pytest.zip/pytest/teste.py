import pytest

from webbrowser import open_new_tab

def teste_site():
    open_new_tab("https://www.mogidascruzes.sp.gov.br/")
    
    
for i in range(3):
    pytest.main(teste_site())

